const API_BASE = 'http://localhost:8081/app';

document.addEventListener('DOMContentLoaded', () => {
    loadSpaces();
    loadReservations();
    loadSpacesForReservation();
});

async function loadSpaces() {
    try {
        const response = await fetch(`${API_BASE}/espacios`);
        const spaces = await response.json();

        spacesList.innerHTML = spaces.map(space =>
            `<div class="space-item">
                <div>
                    <h3>#<span>${space.id}</span> ${space.nombre}</h3>
                    <p>Tipo: ${space.tipo} | Capacidad: ${space.capacidad}</p>
                </div>
                <div class="actions">
                    <button onclick="editSpace(${space.id})">Editar</button>
                    <button onclick="deleteSpace(${space.id})">Eliminar</button>
                </div>
            </div>`
        ).join('');
    } catch (error) {
        console.error('Error cargando espacios:', error);
    }
}

spaceForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
        id: document.getElementById('spaceId').value,
        nombre: document.getElementById('name').value,
        tipo: document.getElementById('type').value,
        capacidad: parseInt(document.getElementById('capacity').value),
        disponibilidad: "activo"
    };

    console.log("id form: "+formData.id.value);


    const spaceId = document.getElementById('spaceId').value;
    const method = spaceId ? 'PUT' : 'POST';
    const url = spaceId ? `${API_BASE}/espacios/${spaceId}` : `${API_BASE}/espacios`;

    console.log("id etiqueta: " + spaceId.value);

    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Error en la solicitud');
        }

        spaceForm.reset();
        loadSpaces();
    } catch (error) {
        console.error('Error guardando espacio:', error);
        alert('No se pudo guardar el espacio. Revisa los datos ingresados.');
    }
});

async function deleteSpace(id) {
    if (confirm('¿Estás seguro de eliminar este espacio?')) {
        try {
            const response = await fetch(`${API_BASE}/espacios/${id}`, { method: 'DELETE' });

            if (!response.ok) {
                throw new Error('Error eliminando espacio');
            }

            loadSpaces();
        } catch (error) {
            console.error('Error eliminando espacio:', error);
        }
    }
}

async function editSpace(id) {
    try {
        const response = await fetch(`${API_BASE}/espacios/${id}`);
        const space = await response.json();

        document.getElementById('spaceId').value = space.id_espacio;
        document.getElementById('name').value = space.nombre;
        document.getElementById('type').value = space.tipo;
        document.getElementById('capacity').value = space.capacidad;
    } catch (error) {
        console.error('Error cargando datos del espacio:', error);
    }
}

async function loadReservations() {
    try {
        const response = await fetch(`${API_BASE}/reservas`);
        const reservations = await response.json();

        console.log(reservations);

        reservationsList.innerHTML = reservations.map(reservation =>
            `<div class="reservation-item">
                <div>
                    <h3>Espacio ID: ${reservation.reserva_espacios.id_espacio}</h3>
                    <p>Fecha: ${reservation.fecha} | ${reservation.hora_inicio} - ${reservation.hora_fin}</p>
                    <p>Estado: ${reservation.estado}</p>
                </div>
                <div class="actions">
                    <button onclick="editReservation(${reservation.id_reserva})">Editar</button>
                    <button onclick="cancelReservation(${reservation.id_reserva})">Cancelar</button>
                </div>
            </div>`
        ).join('');
    } catch (error) {
        console.error('Error cargando reservas:', error);
    }
}

async function loadSpacesForReservation() {
    const select = document.getElementById('spaceIdReservation');
    try {
        const response = await fetch(`${API_BASE}/espacios`);
        const spaces = await response.json();

        select.innerHTML = spaces.map(space =>
            `<option value="${space.id_espacio}">${space.nombre} (${space.tipo})</option>`
        ).join('');
    } catch (error) {
        console.error('Error cargando espacios para reservas:', error);
    }
}

reservationForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
        id_reserva: document.getElementById('reservationId').value || null,
        fecha: document.getElementById('reservationDate').value,
        hora_inicio: document.getElementById('startTime').value + ":00",
        hora_fin: document.getElementById('endTime').value + ":00",
        estado: "Pendiente",
        //id_espacios: parseInt(document.getElementById('spaceIdReservation').value)
        id_espacios: { id_espacio: parseInt(document.getElementById('spaceIdReservation').value) }
    };

    console.log(formData.id_espacios);
    console.log(document.getElementById('spaceIdReservation').value);

    const reservationId = document.getElementById('reservationId').value;
    const method = reservationId ? 'PUT' : 'POST';
    const url = reservationId ? `${API_BASE}/reservas/${reservationId}` : `${API_BASE}/reservas`;

    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Error en la solicitud');
        }

        reservationForm.reset();
        loadReservations();
    } catch (error) {
        console.error('Error guardando reserva:', error);
        alert('No se pudo guardar la reserva. Revisa los datos ingresados.');
    }
});


async function cancelReservation(id) {
    if (confirm('¿Estás seguro de cancelar esta reserva?')) {
        try {
            const response = await fetch(`${API_BASE}/reservas/${id}`, { method: 'DELETE' });

            if (!response.ok) {
                throw new Error('Error cancelando reserva');
            }

            loadReservations();
        } catch (error) {
            console.error('Error cancelando reserva:', error);
        }
    }
}

async function editReservation(id) {
    try {
        const response = await fetch(`${API_BASE}/reservas/${id}`);
        const reservation = await response.json();

        document.getElementById('reservationId').value = reservation.id_reserva;
        document.getElementById('spaceIdReservation').value = reservation.reserva_espacios;
        document.getElementById('reservationDate').value = reservation.fecha;
        document.getElementById('startTime').value = reservation.hora_inicio;
        document.getElementById('endTime').value = reservation.hora_fin;
    } catch (error) {
        console.error('Error cargando datos de la reserva:', error);
    }
}
