package com.examen.examenSpring.controllers;

import com.examen.examenSpring.dto.EspaciosDisponiblesDTO;
import com.examen.examenSpring.entities.EspaciosEntity;
import com.examen.examenSpring.exceptions.ResourceNotFoundException;
import com.examen.examenSpring.exceptions.ResourceWithoutContentException;
import com.examen.examenSpring.services.EspaciosServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/app")
@CrossOrigin(origins = "*")
public class EspaciosController {
    @Autowired
    private EspaciosServices espaciosServices;

    @GetMapping("/espacios")
    public ResponseEntity<List<EspaciosDisponiblesDTO>> espaciosDisponibles(){
        return ResponseEntity.ok(espaciosServices.listaEspaciosDisponibles());
    }

    @GetMapping("/espacios/{id}")
    public ResponseEntity<EspaciosEntity> buscarEspacioPorid(@PathVariable Integer id){
        return ResponseEntity.ok(espaciosServices.buscarEspacioPorId(id));
    }

    @PostMapping("/espacios")
    public ResponseEntity<EspaciosEntity> agregarEspacio(@RequestBody EspaciosEntity espacio){
        if (espacio == null){
            throw new ResourceWithoutContentException("El espacio no contiene datos.");
        }return ResponseEntity.ok(espaciosServices.nuevoEspacio(espacio));
    }

    @PutMapping("/espacios/{id}")
    public ResponseEntity<EspaciosEntity> actualizarEspacio(@PathVariable Integer id,
                                                            @RequestBody EspaciosEntity espacio){
        if (espaciosServices.buscarEspacioPorId(id) == null){
            throw new ResourceNotFoundException("El espacio no existe");
        }return ResponseEntity.ok(espaciosServices.nuevoEspacio(espacio));
    }

    @DeleteMapping("/espacios/{id}")
    public ResponseEntity<Map<String, Boolean>> eliminarEspacio(@PathVariable Integer id){
        EspaciosEntity espacioEncontrado = espaciosServices.buscarEspacioPorId(id);

        if (espacioEncontrado == null){
            throw new ResourceNotFoundException("El espacio no existe.");
        }

        espaciosServices.eliminarEspacio(espacioEncontrado);

        Map<String, Boolean> response = new HashMap<>();
        response.put("eliminado", true);
        return ResponseEntity.ok(response);
    }
}
