package com.examen.examenSpring.dto;

import java.sql.Date;
import java.sql.Time;

public class ReservaDTO {
    private Integer id_reserva;
    private Date fecha;
    private Time hora_inicio;
    private Time hora_fin;
    private String estado;
    private Integer id_espacios;

    public ReservaDTO(){}

    public ReservaDTO(Integer id, Date fecha, Time hora_inicio, Time hora_fin, String estado, Integer id_espacios) {
        this.id_reserva = id;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.estado = estado;
        this.id_espacios = id_espacios;
    }

    public Integer getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(Integer id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Time hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Time getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(Time hora_fin) {
        this.hora_fin = hora_fin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Integer getId_espacios() {
        return id_espacios;
    }

    public void setId_espacios(Integer id_espacios) {
        this.id_espacios = id_espacios;
    }

    @Override
    public String toString() {
        return "ReservaDTO{" +
                "id=" + id_reserva +
                ", fecha=" + fecha +
                ", hora_inicio=" + hora_inicio +
                ", hora_fin=" + hora_fin +
                ", estado='" + estado + '\'' +
                ", id_espacios=" + id_espacios +
                '}';
    }
}
