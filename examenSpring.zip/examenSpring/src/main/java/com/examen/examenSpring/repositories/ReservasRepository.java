package com.examen.examenSpring.repositories;

import com.examen.examenSpring.dto.ReservasActivasDTO;
import com.examen.examenSpring.entities.ReservasEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReservasRepository extends JpaRepository<ReservasEntity, Integer> {
}