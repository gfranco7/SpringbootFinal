package com.examen.examenSpring.entities;

import jakarta.persistence.*;

import java.sql.Date;
import java.sql.Time;

@Entity
@Table(name = "reservas")
public class ReservasEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_reserva;
    @Column(name = "fecha")
    private Date fecha;
    @Column(name = "hora_inicio")
    private Time hora_inicio;
    @Column(name = "hora_fin")
    private Time hora_fin;
    @Column(name = "estado")
    private String estado;

    @ManyToOne
    @JoinColumn(name = "id_espacio")
    private EspaciosEntity id_espacios;

    public ReservasEntity(){}

    public ReservasEntity(Integer id, Date fecha, Time hora_inicio, Time hora_fin, String estado, EspaciosEntity reserva_espacios) {
        this.id_reserva = id;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.estado = estado;
        this.id_espacios = reserva_espacios;
    }

    public Integer getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(Integer id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Time hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Time getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(Time hora_fin) {
        this.hora_fin = hora_fin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public EspaciosEntity getReserva_espacios() {
        return id_espacios;
    }

    public void setReserva_espacios(EspaciosEntity reserva_espacios) {
        this.id_espacios = reserva_espacios;
    }

    @Override
    public String toString() {
        return "ReservasEntity{" +
                "id=" + id_reserva +
                ", fecha=" + fecha +
                ", hora_inicio=" + hora_inicio +
                ", hora_fin=" + hora_fin +
                ", estado='" + estado + '\'' +
                ", reserva_espacios=" + id_espacios +
                '}';
    }
}
