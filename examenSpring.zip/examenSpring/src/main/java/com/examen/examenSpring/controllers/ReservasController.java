package com.examen.examenSpring.controllers;

import com.examen.examenSpring.dto.ReservaDTO;
import com.examen.examenSpring.dto.ReservasActivasDTO;
import com.examen.examenSpring.entities.ReservasEntity;
import com.examen.examenSpring.exceptions.ResourceNotFoundException;
import com.examen.examenSpring.exceptions.ResourceWithoutContentException;
import com.examen.examenSpring.services.ReservasServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/app")
@CrossOrigin(origins = "*")
public class ReservasController {
    @Autowired
    private ReservasServices reservasServices;

    @GetMapping("/reservas")
    public ResponseEntity<List<ReservasEntity>> listaReservas(){
        return ResponseEntity.ok(reservasServices.listaReservasActivas());
    }

    @GetMapping("/reservas/{id}")
    public ResponseEntity<ReservasEntity> buscarReservaPorId(@PathVariable Integer id){
        return ResponseEntity.ok(reservasServices.buscarReservaPorId(id));
    }


    @PostMapping("/reservas")
    public ResponseEntity<ReservasEntity> agregarReserva(@RequestBody ReservaDTO reservaDTO){
        if (reservaDTO == null){
            throw new ResourceWithoutContentException("La reserva no contiene información");
        }

        ReservasEntity reserva = reservasServices.nuevaReserva(reservaDTO);

        return ResponseEntity.ok(reserva);
    }

    @PutMapping("/reservas/{id}")
    public ResponseEntity<ReservasEntity> editarReserva(@PathVariable Integer id,
                                                        @RequestBody ReservaDTO reservaDTO){
        if (reservasServices.buscarReservaPorId(id)== null){
            throw new ResourceNotFoundException("La reserva no existe.");
        }

        return ResponseEntity.ok(reservasServices.nuevaReserva(reservaDTO));
    }

    @DeleteMapping("/reservas/{id}")
    public ResponseEntity<Map<String, Boolean>> eliminarReserva(@PathVariable Integer id){
        ReservasEntity reserva = reservasServices.buscarReservaPorId(id);

        if (reserva == null){
            throw new ResourceNotFoundException("La reserva no existe");
        }

        reservasServices.eliminarReserva(reserva);

        Map<String, Boolean> response = new HashMap<>();
        response.put("eliminado", true);
        return ResponseEntity.ok(response);
    }
}
