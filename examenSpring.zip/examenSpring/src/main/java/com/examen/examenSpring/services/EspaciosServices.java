package com.examen.examenSpring.services;

import com.examen.examenSpring.dto.EspaciosDisponiblesDTO;
import com.examen.examenSpring.entities.EspaciosEntity;
import com.examen.examenSpring.repositories.EspaciosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EspaciosServices {

    @Autowired
    private EspaciosRepository espaciosRepository;

    public List<EspaciosDisponiblesDTO> listaEspaciosDisponibles(){
        return espaciosRepository.espaciosDisponibles();
    }

    public EspaciosEntity nuevoEspacio(EspaciosEntity espacio){
        return espaciosRepository.save(espacio);
    }

    public EspaciosEntity buscarEspacioPorId(Integer id){
        return espaciosRepository.findById(id).orElse(null);
    }

    public void eliminarEspacio(EspaciosEntity espacio){
        espaciosRepository.delete(espacio);
    }
}
