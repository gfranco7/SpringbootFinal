package com.examen.examenSpring.services;

import com.examen.examenSpring.dto.ReservaDTO;
import com.examen.examenSpring.dto.ReservasActivasDTO;
import com.examen.examenSpring.entities.EspaciosEntity;
import com.examen.examenSpring.entities.ReservasEntity;
import com.examen.examenSpring.exceptions.ResourceNotFoundException;
import com.examen.examenSpring.repositories.ReservasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservasServices {
    @Autowired
    private ReservasRepository reservasRepository;
    @Autowired
    private EspaciosServices espaciosServices;

    public List<ReservasEntity> listaReservasActivas(){
        return reservasRepository.findAll();
    }

    public ReservasEntity nuevaReserva(ReservaDTO reservaDTO){
        EspaciosEntity espacioReserva = espaciosServices.buscarEspacioPorId(reservaDTO.getId_espacios());

        if (espacioReserva == null){
            throw new ResourceNotFoundException("La reserva no existe.");
        }

        ReservasEntity reserva = new ReservasEntity();

        reserva.setId_reserva(reservaDTO.getId_reserva());
        reserva.setFecha(reservaDTO.getFecha());
        reserva.setHora_fin(reservaDTO.getHora_fin());
        reserva.setHora_inicio(reservaDTO.getHora_inicio());
        reserva.setEstado(reservaDTO.getEstado());
        reserva.setReserva_espacios(espacioReserva);

        reserva = reservasRepository.save(reserva);

        return reserva;
    }

    public ReservasEntity buscarReservaPorId(Integer id){
        return reservasRepository.findById(id).orElse(null);
    }

    public void eliminarReserva(ReservasEntity reserva){
        reservasRepository.delete(reserva);
    }
}
