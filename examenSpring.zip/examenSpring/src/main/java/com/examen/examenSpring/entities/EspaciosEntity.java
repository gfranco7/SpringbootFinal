package com.examen.examenSpring.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "espacios")
public class EspaciosEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_espacio;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "tipo")
    private String tipo;
    @Column(name = "capacidad")
    private Integer capacidad;
    @Column(name = "disponibilidad")
    private String disponibilidad;

    @OneToMany(mappedBy = "id_espacios", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<ReservasEntity> reservas;

    public EspaciosEntity(){}

    public EspaciosEntity(Integer id, String nombre, String tipo, Integer capacidad, String disponibilidad, List<ReservasEntity> reservas) {
        this.id_espacio = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.capacidad = capacidad;
        this.disponibilidad = disponibilidad;
        this.reservas = reservas;
    }

    public Integer getId_espacio() {
        return id_espacio;
    }

    public void setId_espacio(Integer id_espacio) {
        this.id_espacio = id_espacio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Integer capacidad) {
        this.capacidad = capacidad;
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public List<ReservasEntity> getReservas() {
        return reservas;
    }

    public void setReservas(List<ReservasEntity> reservas) {
        this.reservas = reservas;
    }

    @Override
    public String toString() {
        return "EspaciosEntity{" +
                "id=" + id_espacio +
                ", nombre='" + nombre + '\'' +
                ", tipo='" + tipo + '\'' +
                ", capacidad=" + capacidad +
                ", disponibilidad='" + disponibilidad + '\'' +
                ", reservas=" + reservas +
                '}';
    }
}
