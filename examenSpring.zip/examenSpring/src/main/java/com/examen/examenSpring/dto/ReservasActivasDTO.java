package com.examen.examenSpring.dto;

import java.sql.Date;
import java.sql.Time;

public class ReservasActivasDTO {
    private String id;
    private Date fecha;
    private Time hora_inicio;
    private Time hora_fin;
    private Integer id_espacios;

    public ReservasActivasDTO(){}

    public ReservasActivasDTO(String id, Date fecha, Time hora_inicio, Time hora_fin, Integer reservas_espacios) {
        this.id = id;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.id_espacios = reservas_espacios;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Time hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Time getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(Time hora_fin) {
        this.hora_fin = hora_fin;
    }

    public Integer getId_espacios() {
        return id_espacios;
    }

    public void setId_espacios(Integer id_espacios) {
        this.id_espacios = id_espacios;
    }

    @Override
    public String toString() {
        return "ReservasActivasDTO{" +
                "id='" + id + '\'' +
                ", fecha=" + fecha +
                ", hora_inicio=" + hora_inicio +
                ", hora_fin=" + hora_fin +
                ", reservas_espacios=" + id_espacios +
                '}';
    }
}
