package com.examen.examenSpring.repositories;

import com.examen.examenSpring.dto.EspaciosDisponiblesDTO;
import com.examen.examenSpring.entities.EspaciosEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EspaciosRepository extends JpaRepository<EspaciosEntity, Integer> {
    @Query(value = "SELECT es.id_espacio, es.nombre, es.tipo, es.capacidad FROM espacios es WHERE es.disponibilidad = 'activo';",
            nativeQuery = true)
    List<EspaciosDisponiblesDTO> espaciosDisponibles();
}
